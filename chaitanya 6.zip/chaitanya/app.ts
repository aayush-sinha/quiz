import express = require('express');
import bodyParser = require("body-parser");
const fs = require('fs');
let rawdata = fs.readFileSync('question.json');
let questions = JSON.parse(rawdata);
console.log(questions);
const app: express.Application = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.set("view engine", "ejs");
app.get('/', function (req, res) {
    res.render('home');
})
app.post('/check', function (req, res) {
    let userAns=[];
    let check = [];
    let ans = req.body;
    
    const correctAns = [[1], [0], [0,1], [2], [0], [2],[0], [1], [0]];
    let sum = 0;
    for (var i = 0; i < questions.length; i++) {
        var y = 'ques' + i;
        
        if(req.body[y] != undefined){ 
            userAns[i] =  req.body[y] 
        } else {
            userAns[i] = 9;
            check[i] = 9;
        }
    }
    for (var i = 0; i < questions.length; i++) {
        var x = 'ques' + i

       if(userAns[i].length>1){
            if(userAns[i].length == correctAns[i].length ){
                var flag = 0;
                for(var w = 0;w<correctAns[i].length;w++){
                    if(userAns[i][w] != correctAns[i][w])
                    flag=1;
                    
                }
                if(flag == 0){
                    sum++;
                    check[i] = 1;
                }
                else{
                    check[i] = 0;
                }
        }
        else{
            check[i] = 0;
        }
    }
        else if (userAns[i] == correctAns[i]){
            sum++
            check[i] = 1;}
            else if (userAns[i] != correctAns[i]){
                check[i] = 0;}
}
console.log(check);
console.log(userAns);
console.log(req.body);
    res.render('result', { 'questions': questions, 'sum': sum, 'userAns': userAns, 'correctAns': correctAns, 'check':check,'time':req.body.time });
})
app.get('/test', function (req, res) {

    res.render('test', { 'questions': questions });
});
app.listen(3000, function () {
    console.log('App is listening on port 3000!');
});