show1();
function startTimer(duration, display) {
    var start = Date.now(),
        diff,
        minutes,
        seconds;
    function timer() {
        
        diff = duration - (((Date.now() - start) / 1000) | 0);

        // does the same job as parseInt truncates the float
        minutes = (diff / 60) | 0;
        seconds = (diff % 60) | 0;

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.value ='    Time Left: ' + minutes + ":" + seconds;
        if(minutes<1){
            document.getElementById('time').style.border = '3px solid red'
            document.getElementById('time').style.color = 'red'
        } 
        if(minutes == 0 && seconds ==0){
            
        }
        if (diff <= 0) {
            
            let button = document.getElementById('foo')
            button.click();
        }
        
    };
    // we don't want to wait a full second before the timer starts
    timer();
    setInterval(timer, 1000);
}

window.onload = function () {
    var fiveMinutes = 2*60,
        display = document.querySelector('#time');
    startTimer(fiveMinutes, display);
};
function show1(){
    document.getElementById('first').style.color = 'grey';
    document.getElementById('second').style.color = 'blue';
    document.getElementById('third').style.color = 'blue';
    document.getElementById('content2').style.display = 'none';
    document.getElementById('content3').style.display = 'none';
document.getElementById('content1').style.display = 'block';
}
function show2(){
    document.getElementById('second').style.color = 'grey';
    document.getElementById('first').style.color = 'blue';
    document.getElementById('third').style.color = 'blue';
    document.getElementById('content1').style.display = 'none';
    document.getElementById('content3').style.display = 'none';
    document.getElementById('content2').style.display = 'block'; 
}
function show3(){
    document.getElementById('second').style.color = 'blue';
    document.getElementById('first').style.color = 'blue';
    document.getElementById('third').style.color = 'grey';
    document.getElementById('content1').style.display = 'none';
    document.getElementById('content2').style.display = 'none';
    document.getElementById('content3').style.display = 'block'; 
}

//doughnut
