import express = require('express');
import bodyParser = require("body-parser");
// Create a new express app instance
const app: express.Application = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.set("view engine", "ejs");
app.get('/',function(req,res){
    res.render('home');
})
const questions = [
    {
    'id': 0,
    'data': 'Who is prime minister of India?',
    'options': ['Rahul Gandhi','Narendra Modi','Yogi Aditya'],
    'ans': 1,
    'category': 'Social',
    'page':1
    },
    {
        'id': 1,
        'data': 'Who is captain of Indian cricket team?',
        'options': ['Virat Kohli','Rohit Sharma','MS Dhoni'],
        'ans': 0,
        'category': 'Sports',
    'page':1
    },
    {
        'id': 2,
        'data': 'Which of the following are space organisations?',
        'options': ['NASA','BCCI','ISS'],
        'ans': 0,
        'category': 'Science',
    'page':1
    },
    {
        'id': 3,
        'data': 'Which city is the capital of India',
        'options': ['Mumbai','Banglore','Delhi'],
        'ans': 2,
        'category': 'Social',
    'page':2
    },
    {
        'id': 4,
        'data': 'When were the first recorded olympics held?',
        'options': ['776 BC','400 BC','530 BC'],
        'ans': 1,
        'category': 'Sports',
    'page':2
    }
    ,
    {
        'id': 5,
        'data': 'The term beemer is associated with',
        'options': ['hockey','football','cricket'],
        'ans': 2,
        'category': 'Sports',
    'page':2
    }
    ,
    {
        'id': 6,
        'data': 'Who is home minister of India',
        'options': ['Amit Shah','Sashi Tharoor','Ram Nath'],
        'ans': 0,
        'category': 'Social',
    'page':3
    }
    ,
    {
        'id': 7,
        'data': 'What is the name of the biggest part of the human brain?',
        'options': ['medulla','cerebrum','cerebullum'],
        'ans': 1,
        'category': 'Science',
    'page':3
    }
    ,
    {
        'id': 8,
        'data': 'What substance are nails made of?',
        'options': ['Keratin','Calcium','Carbon'],
        'ans': 0,
        'category': 'Science',
    'page':3
    }
]
app.post('/check',function(req,res){
    let ans = req.body;
    const userAns = Object.values(ans);
    const correctAns = [1,0,0,2,0,2,0,1,0];
  let sum = 0;
  for(var i=0;i<questions.length;i++){
      var x= 'ques'+i
    if(req.body[x] == correctAns[i])
    sum++
  }
   console.log(userAns);
   console.log(correctAns);
//    res.send(propertyValues);
   
res.render('result',{'questions':questions,'sum':sum,'userAns':userAns,'correctAns':correctAns});
})
app.get('/test', function (req, res) {

    res.render('test',{'questions':questions});
    });
app.listen(3000, function () {
console.log('App is listening on port 3000!');
});