import express = require('express');
import bodyParser = require("body-parser");
// Create a new express app instance
const app: express.Application = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.set("view engine", "ejs");
app.get('/',function(req,res){
    res.render('home');
})
const questions = [
    {
    'id': 0,
    'data': 'Who is prime minister of India?',
    'options': ['Rahul Gandhi','Narendra Modi','Yogi Aditya'],
    'ans': 2
    },
    {
        'id': 1,
        'data': 'Who is captain of Indian cricket team?',
        'options': ['Virat Kohli','Rohit Sharma','MS Dhoni'],
        'ans': 1
    },
    {
        'id': 2,
        'data': 'Which of the following are space organisations?',
        'options': ['NASA','BCCI','ISS'],
        'ans': 1
    }

]
app.post('/check',function(req,res){
  let sum = 0;
   if(req.body.ques0 == 2)
   sum++
   if(req.body.ques1 == 1)
   sum++
   if(req.body.ques2 == 1)
   sum++
console.log(sum+1);
 res.render('result',{'sum':sum});
})
app.get('/test', function (req, res) {

    res.render('test',{'questions':questions});
    });
app.listen(3000, function () {
console.log('App is listening on port 3000!');
});