function startTimer(duration, display) {
    var start = Date.now(), diff, minutes, seconds;
    function timer() {
        diff = duration - (((Date.now() - start) / 1000) | 0);
        // does the same job as parseInt truncates the float
        minutes = (diff / 60) | 0;
        seconds = (diff % 60) | 0;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;
        display.textContent = minutes + ":" + seconds;
        if (minutes == 0 && seconds == 0) {
        }
        if (diff <= 0) {
            let button = document.getElementById('foo');
            button.click();
        }
    }
    ;
    // we don't want to wait a full second before the timer starts
    timer();
    setInterval(timer, 1000);
}
window.onload = function () {
    var fiveMinutes = 5 * 60, display = document.querySelector('#time');
    startTimer(fiveMinutes, display);
};
