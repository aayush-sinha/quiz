const questions = [
    {
        'id': 1,
        'data': 'quest 1',
        'ans': 2
    },
    {
        'id': 2,
        'data': 'quest 2',
        'ans': 2
    },
    {
        'id': 3,
        'data': 'quest 3',
        'ans': 2
    }
];
